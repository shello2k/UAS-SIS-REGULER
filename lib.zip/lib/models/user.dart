class User {
  final String name;
  final String role;  

  User({required this.name, required this.role});
}
